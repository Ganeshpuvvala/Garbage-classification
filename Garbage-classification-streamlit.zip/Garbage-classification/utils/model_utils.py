def load_model():
    from tensorflow.keras.models import load_model
    return load_model("model/model.h5")

def predict_image(image, model):
    import numpy as np
    from tensorflow.keras.preprocessing.image import img_to_array

    image = image.resize((224, 224))
    img_array = img_to_array(image) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    predictions = model.predict(img_array)[0]
    label_index = np.argmax(predictions)
    confidence = predictions[label_index] * 100

    class_names = ['Cardboard', 'Glass', 'Metal', 'Paper', 'Plastic', 'Trash']
    return class_names[label_index], confidence