import streamlit as st
from PIL import Image
import os

st.set_page_config(page_title="Garbage Classifier", layout="wide")

st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Home", "Predict", "Metrics"])

if page == "Home":
    st.title("Welcome to Garbage Classification App")
    st.write("""
        This application allows you to classify garbage images into different categories.

        **Pages:**
        - Predict: Upload or capture image to classify.
        - Metrics: View model performance metrics.
    """)

elif page == "Predict":
    from pages.page_predict import predict_page
    predict_page()

elif page == "Metrics":
    from pages.page_metrics import metrics_page
    metrics_page()