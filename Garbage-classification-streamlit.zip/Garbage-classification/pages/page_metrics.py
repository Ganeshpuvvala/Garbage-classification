def metrics_page():
    import streamlit as st
    import matplotlib.pyplot as plt
    import numpy as np

    st.header("📊 Model Performance Metrics")
    st.write("Sample Confusion Matrix (Placeholder)")

    data = np.array([[50, 2, 3], [4, 45, 1], [2, 3, 48]])
    fig, ax = plt.subplots()
    cax = ax.matshow(data, cmap='Blues')
    fig.colorbar(cax)

    st.pyplot(fig)