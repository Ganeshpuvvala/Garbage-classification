def predict_page():
    import streamlit as st
    from PIL import Image
    from utils.model_utils import load_model, predict_image

    st.header("📸 Garbage Image Prediction")

    uploaded_file = st.file_uploader("Upload an image", type=["jpg", "png", "jpeg"])

    if uploaded_file:
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_column_width=True)

        model = load_model()
        label, confidence = predict_image(image, model)

        st.success(f"Predicted: {label} with {confidence:.2f}% confidence")